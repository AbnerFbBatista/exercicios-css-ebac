# Lance Negócios
Projeto para base de conhecimento de CSS Avançado.

## Atividade
- Implementar mais seções que achar necessário.
- Adaptar conteúdo para alguma ideia sua.
- Use a criativadade para criar algo diferente a partir dos conceitos e códigos aprendidos.

## Projeto Base (framework simulator)
- Baixar, instalar e rodar

## Instalação
- Requer o node.js instalado
- Baixar ou clonar este repositório
- Acessar com o terminal a pasta do projeto, baixado e **executar o comando**:
```
npm install 
```
## Execução
- Na raiz do projeto, executar o comando:
```
npm run dev
```